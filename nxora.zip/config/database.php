<?php 

$host = 'localhost';
$db = 'NXORA_db';
$user = 'root';
$pass = '';

try {
    $pdo = new pdo (
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user,
        $pass
    );

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die ("Database connection failed: " . $e->getMessage());
}