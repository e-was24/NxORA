<?php

class Setting
{
    public function get(string $key): ?string
    {
        global $pdo;

        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1");
        $stmt->execute([$key]);

        return $stmt->fetchColumn() ?: null;
    }
}