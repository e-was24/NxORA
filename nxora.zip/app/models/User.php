<?php
class User
{
    public static function findByLogin($login)
    {
        global $pdo;

        $stmt = $pdo->prepare("SELECT * FROM users WHERE email =? OR username = ? LIMIT 1");
        $stmt->execute([$login, $login]);

        return $stmt->fetch();
    }

    public static function findByEmail($email)
    {
        global $pdo;

        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);

        return $stmt->fetch();
    }

    public static function findByEmailOrUsername($email, $username)
    {
        global $pdo;

        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$email, $username]);

        return $stmt->fetch();
    }

    public static function create(array $data)
    {
        global $pdo;

        $stmt = $pdo->prepare("
            INSERT INTO users 
            (uuid, username, email, password, role, status, created_at, updated_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())
        ");

        $stmt->execute([
            $data['uuid'],
            $data['username'],
            $data['email'],
            $data['password'],
            $data['role'] ?? 'user',
            $data['status'] ?? 'pending'
        ]);

        return $pdo->lastInsertId();
    }
}
