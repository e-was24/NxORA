<?php

class Why
{
    public function getActive(): array
    {
        global $pdo;

        $stmt = $pdo->prepare("SELECT text FROM why_items WHERE status = 'active' ORDER BY id ASC" );
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}