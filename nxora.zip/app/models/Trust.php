<?php

class Trust
{
    public function getAll(): array
    {
        global $pdo;

         $stmt = $pdo->query("SELECT text FROM trust_items ORDER BY id ASC");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}