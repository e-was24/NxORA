<?php

class About
{
    public function getImages(): array
    {
        global $pdo;

        $stmt = $pdo->prepare("
            SELECT id, image_name, alt_text 
            FROM about_images 
            ORDER BY id DESC
        ");
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}