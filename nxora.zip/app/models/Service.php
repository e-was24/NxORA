<?php

class Service
{
    public function getActive(): array
    {
        global $pdo;

        $stmt = $pdo->prepare(" SELECT id, title, description, icon FROM services WHERE status = 'active' ORDER BY id DESC" );
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}