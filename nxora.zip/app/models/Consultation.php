<?php

class Consultation
{
    public function create(array $data): bool
    {
        global $pdo;

        $stmt = $pdo->prepare("INSERT INTO consultations (name, email, phone, company, message, status)  VALUES (?, ?, ?, ?, ?, ?)");
        return $stmt->execute([
            $data['name'] ?? '',
            $data['email'] ?? '',
            $data['phone'] ?? '',
            $data['company'] ?? '',
            $data['message'] ?? '',
            'pending'
        ]);
    }
}
