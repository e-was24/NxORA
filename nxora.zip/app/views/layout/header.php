<?php
$currentPage = $_GET['page'] ?? 'register';

$userId = $_SESSION['user_id'] ?? null;
$userRole = $_SESSION['role'] ?? null;
$userLoggedIn = isset($_SESSION['user']);
?>

<!DOCTYPE html>
<html>

<head>
    <?php if ($userLoggedIn): ?>
        <title><?= ($userRole === 'admin') ? 'DASHBOARD' : 'NXORA'; ?></title>
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/styles5.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/landingPage5.css">
</head>

<body>

    <?php if ($userId): ?>
        <?php if ($userRole === 'admin'): ?>
            <header class="admin-navigation">
                <h2>
                    <?= ($_SESSION['role'] === 'admin')
                        ? 'Dashboard <span>Admin</span>'
                        : 'NXORA <span>Grup</span>.'; ?>
                </h2>

                <div class="main_menu_admin">
                    <a href="<?php echo BASE_URL; ?>/?page=adminDashboard"
                        class="<?php echo $currentPage === 'adminDashboard' ? 'active' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                            <path d="M520-600v-240h320v240H520ZM120-440v-400h320v400H120Zm400 320v-400h320v400H520Zm-400 0v-240h320v240H120Zm80-400h160v-240H200v240Zm400 320h160v-240H600v240Zm0-480h160v-80H600v80ZM200-200h160v-80H200v80Zm160-320Zm240-160Zm0 240ZM360-280Z" />
                        </svg>
                        Dashboard
                    </a>

                    <a href="<?php echo BASE_URL; ?>/?page=manage"
                        class="<?php echo $currentPage === 'manage' ? 'active' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                            <path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-507h560v-133H200v133Zm0 214h560v-134H200v134Zm0 213h560v-133H200v133Zm40-454v-80h80v80h-80Zm0 214v-80h80v80h-80Zm0 214v-80h80v80h-80Z" />
                        </svg>
                        Manage
                    </a>

                    <a href="<?php echo BASE_URL; ?>/?page=orders"
                        class="<?php echo $currentPage === 'orders' ? 'active' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                            <path d="M160-160v-516L82-846l72-34 94 202h464l94-202 72 34-78 170v516H160Zm240-280h160q17 0 28.5-11.5T600-480q0-17-11.5-28.5T560-520H400q-17 0-28.5 11.5T360-480q0 17 11.5 28.5T400-440ZM240-240h480v-358H240v358Zm0 0v-358 358Z" />
                        </svg>
                        Orders
                    </a>
                    <a href="<?php echo BASE_URL; ?>/?page=transactions"
                        class="<?php echo $currentPage === 'transactions' ? 'active' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                            <path d="M160-240v-320 13-173 480Zm0-400h640v-80H160v80Zm307 480H160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h640q33 0 56.5 23.5T880-720v210q-36-25-78-37.5T716-560q-54 0-104 21t-88 59H160v240h283q3 21 9 41t15 39Zm320-25 28-28-75-75v-112h-40v128l87 87ZM721-80q-84 0-142.5-58T520-280q0-84 58.5-142T721-480q83 0 141 58.5T920-280q0 83-58 141.5T721-80Z" />
                        </svg>
                        Transactions
                    </a>
                </div>

                <div class="menu_status">
                    <a href="<?php echo BASE_URL; ?>/?page=logout" style="color: orangered;  text-decoration: none;">Logout</a>
                </div>
            </header>
        <?php elseif ($userRole === 'user'): ?>
            <header class="navbar">
                <h2>NXORA <span>Grup</span>.</h2>

                <?php if ($userId): ?>

                    <?php if ($userRole === 'user'): ?>
                        <div class="main_menu">
                            <a href="<?php echo BASE_URL; ?>/?page=dashboard"
                                class="<?php echo $currentPage === 'dashboard' ? 'active' : ''; ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                                    <path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z" />
                                </svg>
                                Home
                            </a>

                            <a href="<?php echo BASE_URL; ?>/?page=agriculture"
                                class="<?php echo $currentPage === 'agriculture' ? 'active' : ''; ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                                    <path d="M160-600q-17 0-28.5-11.5T120-640q0-17 11.5-28.5T160-680h120q33 0 56.5 23.5T360-600H160Zm80 360q50 0 85-35t35-85q0-50-35-85t-85-35q-50 0-85 35t-35 85q0 50 35 85t85 35Zm582.5-17.5Q840-275 840-300t-17.5-42.5Q805-360 780-360t-42.5 17.5Q720-325 720-300t17.5 42.5Q755-240 780-240t42.5-17.5ZM240-300q-25 0-42.5-17.5T180-360q0-25 17.5-42.5T240-420q25 0 42.5 17.5T300-360q0 25-17.5 42.5T240-300Zm560-139q26 5 43 13.5t37 27.5v-242q0-33-23.5-56.5T800-720H548l-42-44 56-56-28-28-142 142 30 28 56-56 42 42v92q0 33-23.5 56.5T440-520h-81q23 17 37 35t28 45h16q66 0 113-47t47-113v-40h200v201ZM641-320q6-27 14.5-43.5T682-400H436q4 23 4 40t-4 40h205Zm139 160q-58 0-99-41t-41-99q0-58 41-99t99-41q58 0 99 41t41 99q0 58-41 99t-99 41Zm-540 0q-83 0-141.5-58.5T40-360q0-83 58.5-141.5T240-560q83 0 141.5 58.5T440-360q0 83-58.5 141.5T240-160Zm393-360Z" />
                                </svg>
                                Agriculture
                            </a>

                            <a href="<?php echo BASE_URL; ?>/?page=store"
                                class="<?php echo $currentPage === 'store' ? 'active' : ''; ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                                    <path d="M160-720v-80h640v80H160Zm0 560v-240h-40v-80l40-200h640l40 200v80h-40v240h-80v-240H560v240H160Zm80-80h240v-160H240v160Zm-38-240h556-556Zm0 0h556l-24-120H226l-24 120Z" />
                                </svg>
                                UI Store
                            </a>
                        </div>

                        <div class="menu_status">
                            <a href="<?php echo BASE_URL; ?>/?page=logout" style="color: orangered;  text-decoration: none;">Logout</a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </header>
        <?php endif; ?>
    <?php else: ?>
        <header class="navbar">
            <h2>NXORA <span>Grup</span>.</h2>

            <!-- <div class="main_menu">
                            <a href="<?php echo BASE_URL; ?>/?page=landingpage" style="display: flex; justify-content: center; align-items: center; gap: .5rem; padding: 5px 10px;"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/></svg>Home</a>
                        </div> -->
            <div class="menu_status">
                <a href="<?php echo BASE_URL; ?>?page=landingpage" style="color: white;">Home</a> |
                <a href="<?php echo BASE_URL; ?>?page=login" style="color:white;">Login</a> |
                <a href="<?php echo BASE_URL; ?>?page=register" style="color:white;">Register</a>
            </div>
        </header>
    <?php endif; ?>