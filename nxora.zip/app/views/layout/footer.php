<hr>
<footer>
    <p>© <?php echo date('Y'); ?> <span class="NXORA"> NXORA <span style="font-size: .8em;">Grup</span>. </span><span class="x">x</span><span class="lanova"> LanovaTech. </span></p>
</footer>

</body>
</html>
