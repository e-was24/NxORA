<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nxora | Landing Page</title>
</head>

<body>
    <!-- hero -->

    <div class="hero">
        <div class="hero_container">
            <h1 class="hero_title"><?= htmlspecialchars($heroTitle ?? '') ?></h1>
            <p class="hero_subtitle"><?= htmlspecialchars($heroSubtitle ?? '') ?></p>
            <div class="hero_buttons">
                <button class="btn btn-primary" onclick="window.location.href='<?= BASE_URL ?>/login'">
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                        <path d="m226-559 78 33q14-28 29-54t33-52l-56-11-84 84Zm142 83 114 113q42-16 90-49t90-75q70-70 109.5-155.5T806-800q-72-5-158 34.5T492-656q-42 42-75 90t-49 90Zm155-121.5q0-33.5 23-56.5t57-23q34 0 57 23t23 56.5q0 33.5-23 56.5t-57 23q-34 0-57-23t-23-56.5ZM565-220l84-84-11-56q-26 18-52 32.5T532-299l33 79Zm313-653q19 121-23.5 235.5T708-419l20 99q4 20-2 39t-20 33L538-80l-84-197-171-171-197-84 167-168q14-14 33.5-20t39.5-2l99 20q104-104 218-147t235-24ZM157-321q35-35 85.5-35.5T328-322q35 35 34.5 85.5T327-151q-25 25-83.5 43T82-76q14-103 32-161.5t43-83.5Zm57 56q-10 10-20 36.5T180-175q27-4 53.5-13.5T270-208q12-12 13-29t-11-29q-12-12-29-11.5T214-265Z" />
                    </svg>
                    Get Started
                </button>
                <button class="btn btn-outline" onclick="window.location.href='<?= BASE_URL ?>/consultation'">
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                        <path d="m408-432-42-42q8-11 11-22.5t3-23.5q0-12-3-23.5T366-565l42-43q16 19 24 42t8 46q0 23-8 45.5T408-432Zm85 86-43-43q25-28 37.5-62t12.5-69q0-35-12.5-68.5T450-650l43-43q34 37 50.5 81.5T560-520q0 47-16.5 92T493-346ZM200-480q-33 0-56.5-23.5T120-560q0-33 23.5-56.5T200-640q33 0 56.5 23.5T280-560q0 33-23.5 56.5T200-480ZM40-320v-23q0-24 13-44t36-30q26-11 53.5-17t57.5-6q30 0 57.5 6t53.5 17q23 10 36 30t13 44v23H40Zm720-160q-33 0-56.5-23.5T680-560q0-33 23.5-56.5T760-640q33 0 56.5 23.5T840-560q0 33-23.5 56.5T760-480ZM600-320v-23q0-24 13-44t36-30q26-11 53.5-17t57.5-6q30 0 57.5 6t53.5 17q23 10 36 30t13 44v23H600Z" />
                    </svg>
                    Free Consultation
                </button>
            </div>
        </div>
    </div>

    <!-- trust -->

    <section class="trust">
        <h3 class="trust_title">
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                <path d="M475-160q4 0 8-2t6-4l328-328q12-12 17.5-27t5.5-30q0-16-5.5-30.5T817-607L647-777q-11-12-25.5-17.5T591-800q-15 0-30 5.5T534-777l-11 11 74 75q15 14 22 32t7 38q0 42-28.5 70.5T527-522q-20 0-38.5-7T456-550l-75-74-175 175q-3 3-4.5 6.5T200-435q0 8 6 14.5t14 6.5q4 0 8-2t6-4l136-136 56 56-135 136q-3 3-4.5 6.5T285-350q0 8 6 14t14 6q4 0 8-2t6-4l136-135 56 56-135 136q-3 2-4.5 6t-1.5 8q0 8 6 14t14 6q4 0 7.5-1.5t6.5-4.5l136-135 56 56-136 136q-3 3-4.5 6.5T454-180q0 8 6.5 14t14.5 6Zm-1 80q-37 0-65.5-24.5T375-166q-34-5-57-28t-28-57q-34-5-56.5-28.5T206-336q-38-5-62-33t-24-66q0-20 7.5-38.5T149-506l232-231 131 131q2 3 6 4.5t8 1.5q9 0 15-5.5t6-14.5q0-4-1.5-8t-4.5-6L398-777q-11-12-25.5-17.5T342-800q-15 0-30 5.5T285-777L144-635q-9 9-15 21t-8 24q-2 12 0 24.5t8 23.5l-58 58q-17-23-25-50.5T40-590q2-28 14-54.5T87-692l141-141q24-23 53.5-35t60.5-12q31 0 60.5 12t52.5 35l11 11 11-11q24-23 53.5-35t60.5-12q31 0 60.5 12t52.5 35l169 169q23 23 35 53t12 61q0 31-12 60.5T873-437L545-110q-14 14-32.5 22T474-80Zm-99-560Z" />
            </svg>
            TRUST
        </h3>
        <div class="trust_container">
            <?php foreach ($trustItems ?? [] as $trust): ?>
                <div class="trust_item">
                    <?= htmlspecialchars(($trust['text'])) ?>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    <br>
    <!-- About -->
    <section class="about">
        <h3 class="about_title">About<span class="NXORA"> NXORA <span style="font-size: .8em;">Grup</span>. </h3>
        <div class="about_container">
            <div class="about_content"><?= htmlspecialchars($aboutContent ?? '') ?></div>
            <div class="about_image">
                <?php if (!empty($aboutImages)): ?>
                    <?php foreach ($aboutImages as $img): ?>
                        <div class="about_img_item">
                            <img
                                src="assets/img/<?= htmlspecialchars($img['image_name']) ?>"
                                alt="<?= htmlspecialchars($img['alt_text']) ?>">
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No images available</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- services -->
    <section class="services">
        <h3 class="services_title">
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                <path d="M280-720v-40q0-33 23.5-56.5T360-840h240q33 0 56.5 23.5T680-760v40h28q24 0 43.5 13.5T780-672l94 216q3 8 4.5 16t1.5 16v184q0 33-23.5 56.5T800-160H160q-33 0-56.5-23.5T80-240v-184q0-8 1.5-16t4.5-16l94-216q9-21 28.5-34.5T252-720h28Zm80 0h240v-40H360v40Zm-80 240v-40h80v40h240v-40h80v40h96l-68-160H252l-68 160h96Zm0 80H160v160h640v-160H680v40h-80v-40H360v40h-80v-40Zm200-40Zm0-40Zm0 80Z" />
            </svg>
            our services
        </h3>
        <div class="services_container">
            <?php foreach ($services ?? [] as $service) : ?>
                <div class="services_card">
                    <h4 class="card_title"><?= htmlspecialchars($service['title']) ?></h4>
                    <p><?= htmlspecialchars($service['description']) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- why -->
    <section class="why">
        <h3 class="why_title"><?= htmlspecialchars($settingModel->get('why_title') ?? 'Why Choose Us') ?></h3>
        <div class="why_container">
            <div class="why_list">
                <ul>
                    <?php foreach ($whyItems ?? [] as $item): ?>
                        <li><?= htmlspecialchars($item['text']) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </section>

    <!-- partner kami -->
    <section class="Partnership">
        <h3 class="partner_title"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                <path d="M480-600 340-740l140-140 140 140-140 140ZM40-160v-160q0-34 23.5-57t56.5-23h131q20 0 38 10t29 27q29 39 71.5 61t90.5 22q49 0 91.5-22t70.5-61q13-17 30.5-27t36.5-10h131q34 0 57 23t23 57v160H640v-91q-35 25-75.5 38T480-200q-43 0-84-13.5T320-252v92H40Zm120-280q-50 0-85-35t-35-85q0-51 35-85.5t85-34.5q51 0 85.5 34.5T280-560q0 50-34.5 85T160-440Zm640 0q-50 0-85-35t-35-85q0-51 35-85.5t85-34.5q51 0 85.5 34.5T920-560q0 50-34.5 85T800-440Z" />
            </svg> business partner </h3>
        <div class="cover">
            <!-- card -->
            <div class="card_mitra">
                <a href="http://localhost/ladi_vault/" target="_blank">
                    <img src="assets/img/light_logo.png" alt="Partnership" width="100" height="100">
                </a>
                <p>LaDi Vault.com</p>
            </div>
            <div class="card_mitra">
                <a href="http://localhost/ladi_vault/" target="_blank">
                    <img src="assets/img/light_depster.png" alt="Partnership" width="100" height="100">
                </a>
                <p>Depster.io</p>
            </div>
            <div class="card_mitra">
                <a href="http://localhost/dimasstore/frontend/public/" target="_blank">
                    <img src="assets/img/light_topupin.png" alt="Partnership" width="100" height="100">
                </a>
                <p>tupupin.id</p>
            </div>
        </div>
    </section>
</body>

</html>