<?php
if (isset($_SESSION['user'])) {
    header('Location: ' . BASE_URL . '/dashboard');
    exit;
}

$error = $_GET['error'] ?? null;
$success = $_GET['success'] ?? null;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>

<body>
    <div class="paper_cover">
        <div class="paper">
            <h2 style="display: flex; justify-content: center; align-items: center;">Register</h2>

            <?php if ($error): ?>
                <p style="color: red;">
                    <?php echo htmlspecialchars($error) ?>
                </p>
            <?php endif; ?>

            <?php if ($success): ?>
                <p style="color: green;">
                    Register berhasil Silahkan login.
                </p>
            <?php endif; ?>

            <form action="<?php echo BASE_URL; ?>/?page=register" method="post">
                <div class="input_bar">
                    <label>Username :</label><br>
                    <input type="text" name="username" placeholder="username" required>
                </div>

                <br>

                <div class="input_bar">
                    <label>Email :</label><br>
                    <input type="email" name="email" placeholder="example@gmail.com" required>
                </div>

                <br>

                <div class="input_bar">
                    <label>Password :</label><br>
                    <input type="password" name="password" placeholder="password" required>
                </div>

                <br>

                <div class="input_bar">
                    <label>Confirm Password :</label><br>
                    <input type="password" name="password_confirm" placeholder="password confirm" required>
                </div>

                <br>

                <div class="button_section">
                    <button type="submit">Register</button>
                    <a href="<?php echo BASE_URL; ?>/?page=login">login</a>
                </div>
            </form>
        </div>
    </div>
</body>

</html>