<section class="consultation">
    <div class="container">
        <h2>Free Consultation</h2>
        <p>Tell us about your project and we'll get back to you.</p>

        <?php if (!empty($_SESSION['success'])): ?>
            <div class="alert-success">
                <?= htmlspecialchars($_SESSION['success']);
                unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($_SESSION['error'])): ?>
            <div class="alert-error">
                <?= htmlspecialchars($_SESSION['error']);
                unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <form action="<?= BASE_URL ?>/consultation" method="post">
            <div class="form-grup">
                <label>Full Name :</label>
                <input type="text" name="name" placeholder="Udin sedunia" required>
            </div>
            <div class="form-grup">
                <label>Email :</label>
                <input type="email" name="email" placeholder="example@gmail.com" required>
            </div>
            <div class="form-grup">
                <label>Phone :</label>
                <input type="text" name="phone" placeholder="(+62) 82212314326">
            </div>
            <div class="form-grup">
                <label>Company :</label>
                <input type="text" name="company" placeholder="[Company / business name] inc.">
            </div>
            <div class="form-grup">
                <label>Project Details :</label>
                <textarea name="message" rows="5" placeholder="write your complaint or question here..." required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">
                Send Consultation Request
            </button>
        </form>
        <p>Build your business future with the right plan.</p>
    </div>
</section>