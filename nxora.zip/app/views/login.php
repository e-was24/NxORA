<?php

if (isset($_SESSION['user'])) {
    header('Location: ' . BASE_URL . '/dashboard');
    exit;
}

$error = $_GET['error'] ?? null;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>

<body>
    <div class="paper_cover">
        <div class="paper">
            <h2 style="display: flex; justify-content: center; align-items: center;">
                Login
            </h2>

            <?php $registered = $_GET['registered'] ?? null;
            if ($registered): ?>
                <p style="color: lightgreen;">
                    register berhasil. silahkan login.
                </p>
            <?php endif; ?>




            <?php if ($error): ?>
                <p class="error">
                    Email atau password salah.
                </p>
            <?php endif; ?>

            <form method="POST" action="<?php echo BASE_URL; ?>/?page=login">
                <div class="input_bar">
                    <label>Email :</label>
                    <input type="email" name="email" placeholder="example@gmail.com" require autocomplete="email">
                </div>
                <br>
                <div class="input_bar">
                    <label>Password :</label>
                    <input type="password" name="password" placeholder="password" required autocomplete="current-password">
                </div>
                <br>
                <div class="button_section">
                    <button type="submit">
                        Login
                    </button>
                    <a href="<?php echo BASE_URL; ?>/?page=register">Register</a>
                </div>
            </form>
        </div>
    </div>
</body>

</html>