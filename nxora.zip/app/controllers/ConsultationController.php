<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../models/Consultation.php';

class ConsultationController
{
    public function send()
    {

        if ($_SERVER["REQUEST_METHOD"] === "POST") {

            $data = [
                'name'    => htmlspecialchars($_POST['name']),
                'email'   => htmlspecialchars($_POST['email']),
                'phone'   => htmlspecialchars($_POST['phone']),
                'company' => htmlspecialchars($_POST['company']),
                'message' => htmlspecialchars($_POST['message']),
            ];

            $model = new Consultation();

            if (!$model->create($data)) {
                $_SESSION['error'] = "Failed to save consultation.";
                header("Location: " . BASE_URL . "/?page=consultation");
                exit;
            }

            $mail = new PHPMailer(true);

            try {

                $mail->isSMTP();
                $mail->Host       = $_ENV['MAIL_HOST'];
                $mail->SMTPAuth   = true;
                $mail->Username   = $_ENV['MAIL_USERNAME'];
                $mail->Password   = $_ENV['MAIL_PASSWORD'];
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = $_ENV['MAIL_PORT'];

                $mail->setFrom($_ENV['MAIL_USERNAME'], 'NXORA Store Official');
                $mail->addAddress($_ENV['MAIL_TO']);
                $mail->addReplyTo($data['email'], $data['name']);

                $mail->isHTML(true);
                $mail->Subject = 'NXORA - New Consultation Request';

                $mail->Body = "
                    <h3>New Consultation</h3>
                    <p><strong>Name:</strong> {$data['name']}</p>
                    <p><strong>Email:</strong> {$data['email']}</p>
                    <p><strong>Phone:</strong> {$data['phone']}</p>
                    <p><strong>Company:</strong> {$data['company']}</p>
                    <p><strong>Message:</strong><br>{$data['message']}</p>
                ";

                $mail->AltBody = "New consultation from NXORA website.";

                $mail->send();

                $_SESSION['success'] = "Consultation request sent successfully!";
                header("Location: " . BASE_URL . "/?page=consultation");
                exit;

            } catch (Exception $e) {

                $_SESSION['error'] = "Email failed to send.";
                header("Location: " . BASE_URL . "/?page=consultation");
                exit;
            }
        }
    }
}