<?php

$_SESSION['login_agent'] = hash(
    'sha256',
    $_SERVER['HTTP_USER_AGENT'] ?? ''
);

class AuthController
{

    public function showLogin()
    {
        require __DIR__ . '/../views/login.php';
    }

    public function login()
    {
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        $user = User::findByEmail($email);

        if (!$user || !password_verify($password, $user['password'])) {
            redirect(BASE_URL . '/?page=login&error=1');
        }

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];

        session_regenerate_id(true);

        if ($user['role'] === 'admin') {
            redirect(BASE_URL . '/?page=adminDashboard');
        }

        redirect(BASE_URL . '/?page=dashboard');
    }

    public function register()
    {
        $username = $_POST['username'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $password_confirm = $_POST['password_confirm'] ?? '';

        if ($password !== $password_confirm) {
            header('Location: ' . BASE_URL . '/?page=register&error=Password tidak cocok');

            exit;
        }

        $existing = User::findByEmailOrUsername($email, $username);
        if ($existing) {
            header('Location: ' . BASE_URL . '/?page=register&error=Email atau username sudah terpakai');
            exit;
        }

        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $uuid = generate_uuid();

        User::create([
            'username' => $username,
            'email' => $email,
            'password' => $password_hash,
            'role' => 'user',
            'status' => 'pending',
            'uuid' => $uuid

        ]);
        header('Location: ' . BASE_URL . '/?page=login&registered=1');
        exit;
    }

    // public function logout()
    // {
    //     $_SESSION = [];

    //     if (ini_get("session.use_cookies")) {
    //         $params = session_get_cookie_params();
    //         setcookie(
    //             session_name(),
    //             '',
    //             time() - 42000,
    //             $params["path"] .
    //                 $params["domain"],
    //             $params["secure"],
    //             $params["httponly"]
    //         );
    //     }

    //     session_destroy();

    //     header('Location: ' . BASE_URL . '/?page=login');
    //     exit;
    // }

    public function logout()
    {
        session_unset();
        session_destroy();

        redirect(BASE_URL . '/?page=landingpage');
    }
}
